import pygame,pygame.mixer,math
from pygame.locals import*
#dimiourgia tou para8irou tis pygame
pygame.init()
screenSize=(750,600)
screen=pygame.display.set_mode(screenSize,DOUBLEBUF)
pygame.display.set_caption('M A Z E')
ex=True
x=347
y=125
character= pygame.image.load('../images/char.png')
character=pygame.transform.scale(character,(10,10))
screen.blit(character,(x,y))
start=pygame.image.load('../images/stage1.bmp')
start=pygame.transform.scale(start,(775,600))
screen.blit(start,(0,0))
pygame.display.update()   
k=0
u='d'
i=0
white=(255,255,255)
color=(200,155,64)
#p=o ari8mos twn 'klik'
p=0
e=1
color=(0,0,0)
ex=True
#sintetagmenes teratwn 4ou epipedou
t1x=285
t1y=239
t2x=415
t2y=376
ky=550
kx=305
sx=305
sy=550
epanalipseis=0
epanalipseis1=0
#elegxos gia emfanisi toixwn...
l=True 
zwes=3
while ex :
  mx,my= pygame.mouse.get_pos()
  if p>1 and p%2==0 :
    x=mx-10
    y=my-10
  for event in pygame.event.get():
     if event.type == pygame.QUIT:
       ex=False
     elif event.type==MOUSEBUTTONDOWN: 
       if p%2==1 and (((mx-x)*(mx-x)+(my-y)*(my-y))<600):
         p=p+1
       elif p%2==0 and e==1:
         p=p+1
       l=True
     elif event.type== KEYDOWN and event.key== K_ESCAPE:
       ex=False  
     elif event.type==KEYDOWN and event.key==K_1:
       p=1
       x=347
       y=125
     elif event.type==KEYDOWN and event.key==K_2:
       p=3
       x=347
       y=125
     elif event.type==KEYDOWN and event.key==K_3:
       p=5
       x=285
       y=100
     elif event.type==KEYDOWN and event.key==K_4:
       p=7
       x=347
       y=125
     elif event.type==KEYDOWN and event.key==K_5:
       p=9
       x=160
       y=105
     elif event.type==KEYDOWN and event.key==K_r:
       p=1
       zwes=3
       l=True
       x=347
       y=125
       sound.stop()
  #fodo,ixoi,toixoi 1ou epipedou
  if p==1 or p==2 and l==True: 
    screen.fill(white)
    bg=pygame.image.load('../images/bg1.bmp')
    bg=pygame.transform.scale(bg,(750,600))
    screen.blit(bg,(0,0))
    lives= pygame.image.load('../images/aspra.png')
    lives=pygame.transform.scale(lives,(120,140))
    screen.blit(lives,(-10,-20))
    character= pygame.image.load('../images/char1.png')
    character=pygame.transform.scale(character,(30,30))
    screen.blit(character,(x,y)) 
    if zwes==3: 
      ari8mos=pygame.image.load('../images/aspro_3.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    if zwes==2: 
      ari8mos=pygame.image.load('../images/aspro_2.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))  
    if zwes==1: 
      ari8mos=pygame.image.load('../images/aspro_1.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    screen.lock()
    pygame.draw.line(screen,(124,187,255), (330 , 123),(330,499), 5)
    pygame.draw.line(screen,(124,187,255), (390 , 123),(390,499), 5)
    screen.unlock() 
    pygame.display.flip()
    e=0
  #fodo,ixoi,toixoi 2ou epipedou
  if p==3 or p==4 and l==True:
    screen.fill(white)
    bg=pygame.image.load('../images/bg2.bmp')
    bg=pygame.transform.scale(bg,(750,600))
    screen.blit(bg,(0,0))
    character= pygame.image.load('../images/char2.png')
    character=pygame.transform.scale(character,(30,30))
    screen.blit(character,(x,y))
    lives= pygame.image.load('../images/adiaf.png')
    lives=pygame.transform.scale(lives,(120,140))
    screen.blit(lives,(-10,-20))
    if zwes==3: 
      ari8mos=pygame.image.load('../images/adiaf_3.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    if zwes==2: 
      ari8mos=pygame.image.load('../images/adiaf_2.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))  
    if zwes==1: 
      ari8mos=pygame.image.load('../images/adiaf_1.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    screen.lock()
    pygame.draw.line(screen, color, (347 , 122),(560,122), 5)
    pygame.draw.line(screen, color, (347 , 170),(510,170), 5)
    pygame.draw.line(screen, color, (560 , 122),(560,335), 5)
    pygame.draw.line(screen, color, (510 , 170),(510,290), 5)
    pygame.draw.line(screen, color, (560 ,335),(347,335), 5)
    pygame.draw.line(screen, color, (510 ,290 ),(347,290), 5)
    screen.unlock()   
    pygame.display.flip()
    e=0
  #fodo,ixoi,toixoi 3ou epipedou
  if p==5 or p==6 and l==True:
    screen.fill(white)
    bg=pygame.image.load('../images/bg3.bmp')
    bg=pygame.transform.scale(bg,(750,600))
    screen.blit(bg,(0,0))
    character= pygame.image.load('../images/char3.png')
    character=pygame.transform.scale(character,(30,30))
    screen.blit(character,(x,y))
    lives= pygame.image.load('../images/aspra.png')
    lives=pygame.transform.scale(lives,(120,140))
    screen.blit(lives,(-10,-20))
    if zwes==3: 
      ari8mos=pygame.image.load('../images/aspro_3.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    if zwes==2: 
      ari8mos=pygame.image.load('../images/aspro_2.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))  
    if zwes==1: 
      ari8mos=pygame.image.load('../images/aspro_1.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,110))
      screen.blit(ari8mos,(75,-5))
    screen.lock()
    pygame.draw.line(screen,white, (275 , 100),(275,255), 5)
    pygame.draw.line(screen,white, (320 , 100),(320,210), 5)
    pygame.draw.line(screen,white, (275 , 255),(400,255), 5)
    pygame.draw.line(screen,white, (320 , 210),(445,210), 5)
    pygame.draw.line(screen,white, (400 ,255),(400,350), 5)
    pygame.draw.line(screen,white, (445 ,210 ),(445,400), 5)
    pygame.draw.line(screen,white, (400 ,350),(300,350), 5)
    pygame.draw.line(screen,white, (445 ,400 ),(300,400), 5)
    screen.unlock()   
    pygame.display.flip()
    e=0
  #fodo,ixoi,toixoi 4ou epipedou
  if p==7 or p==8 and l==True:
    screen.fill(white)
    bg=pygame.image.load('../images/bg4.bmp')
    bg=pygame.transform.scale(bg,(750,600))
    screen.blit(bg,(0,0))
    character= pygame.image.load('../images/char4.png')
    character=pygame.transform.scale(character,(30,30))
    screen.blit(character,(x,y))
    lives= pygame.image.load('../images/aspra.png')
    lives=pygame.transform.scale(lives,(120,140))
    screen.blit(lives,(-10,-20))
    if zwes==3: 
      ari8mos=pygame.image.load('../images/aspro_3.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))
    if zwes==2: 
      ari8mos=pygame.image.load('../images/aspro_2.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))  
    if zwes==1: 
      ari8mos=pygame.image.load('../images/aspro_1.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))
    #kinisi adipalwn
    if t1x==415 or t2x==285 or t1x>415 or t2x<285:
      t1p=-5
      t2p=+5
    elif t1x==285 or t2x==415 or t2x>415 or t1x<285:
      t1p=+5
      t2p=-5
    if t1x<=415:
      t1x=t1x+t1p
    if t2x>=285:
      t2x=t2x+t2p
    screen.lock()
    pygame.draw.line(screen,(252,255,114), (280 , 123),(280,499), 5)
    pygame.draw.line(screen,(252,255,114), (450 , 123),(450,499), 5)
    screen.unlock()
    teras1= pygame.image.load('../images/teras1.png')
    teras1=pygame.transform.scale(teras1,(30,30))
    screen.blit(teras1,(t1x,t1y))
    teras2=pygame.image.load('../images/teras2.png')
    teras2=pygame.transform.scale(teras2,(30,30))
    screen.blit(teras2,(t2x,t2y))
    pygame.display.flip()
    e=0
  #fodo,ixoi,toixoi 5ou epipedou
  if p==9 or p==10 and l==True:
    screen.fill(white)
    bg=pygame.image.load('../images/bg5.bmp')
    bg=pygame.transform.scale(bg,(750,600))
    screen.blit(bg,(0,0))
    lives= pygame.image.load('../images/aspra.png')
    lives=pygame.transform.scale(lives,(120,140))
    screen.blit(lives,(-10,-20))
    character= pygame.image.load('../images/char5.png')
    character=pygame.transform.scale(character,(30,30))
    screen.blit(character,(x,y))
    if zwes==3: 
      ari8mos=pygame.image.load('../images/aspro_3.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))
    if zwes==2: 
      ari8mos=pygame.image.load('../images/aspro_2.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))  
    if zwes==1: 
      ari8mos=pygame.image.load('../images/aspro_1.png')
      ari8mos=pygame.transform.scale(ari8mos,(100,100))
      screen.blit(ari8mos,(75,-5))
    if sy==300 or(epanalipseis1>=3 and sy==480) :
      epanalipseis=epanalipseis+1
      sound=pygame.mixer.Sound('../sounds/piou.wav')
      sound.play()
      sx=sx+40
      epanalipseis1=epanalipseis1+1
      if epanalipseis==5:
        sx=305
        epanalipseis=0
        epanalipseis1=0
      sy=550
      vlima=pygame.image.load('../images/vlima.png')
      vlima=pygame.transform.scale(vlima,(15,20))
      screen.blit(vlima,(sx,sy))
    else:
      sy=sy-10
      vlima=pygame.image.load('../images/vlima.png')
      vlima=pygame.transform.scale(vlima,(15,20))
      screen.blit(vlima,(sx,sy))
    screen.lock()
    pygame.draw.line(screen,(255,61,61), (100 , 101),(300,301), 5)
    pygame.draw.line(screen,(255,61,61), (210 , 101),(410,301), 5)
    pygame.draw.line(screen,(255,61,61), (300 , 301),(300,600), 5)
    pygame.draw.line(screen,(255,61,61), (410,301),(410,481), 5)
    pygame.draw.line(screen,(255,61,61), (300 , 600),(500,600), 5)
    pygame.draw.line(screen,(255,61,61), (410 , 481),(570,481), 5)
    pygame.draw.line(screen,(255,61,61), (500 , 600),(500,520), 5)
    pygame.draw.line(screen,(255,61,61), (500 , 520),(570,520), 5)
    screen.unlock()
    kanoni=pygame.image.load('../images/teras3.png')
    kanoni=pygame.transform.scale(kanoni,(30,20))
    screen.blit(kanoni,(kx-9,ky))
    screen.blit(kanoni,(kx+31,ky))
    screen.blit(kanoni,(kx+71,ky))
    screen.blit(kanoni,(kx+111,ky))
    screen.blit(kanoni,(kx+151,ky))
    pygame.display.flip()
    e=0
  #oria kinisis 1ou epipedou  
  if (x<333  or x>360 or y<110) and p==2 and l==True:
    zwes=zwes-1
    if zwes==0:
      screen.fill(white)
      p=0
      lost=pygame.image.load('../images/lost.bmp')
      lost=pygame.transform.scale(lost,(775,600))
      screen.blit(lost,(0,0))
      pygame.display.flip()
      sound=pygame.mixer.Sound('../sounds/defeat.wav')
      sound.play()
    x=347
    y=125
    p=p-1
  #oria kinisis 2ou epipedou
  if ((x<339 and y<180) or x>530 or y<120 or y>305 or (x<510 and y > 140 and y < 290)) and p==4 and l==True:
    zwes=zwes-1
    if zwes==0:
      screen.fill(white)
      p=0
      lost=pygame.image.load('../images/lost.bmp')
      lost=pygame.transform.scale(lost,(775,600))
      screen.blit(lost,(0,0))
      pygame.display.flip()
      sound=pygame.mixer.Sound('../sounds/defeat.wav')
      sound.play()
    x=347
    y=125
    p=p-1
  #oria kinisis 3ou epipedou
  if (((x<275)and y<300) or (x>289 and y<106) or (y>224 and x>276 and x<402 and y<300) or (x<414 and x>289 and y<211) or (x<395 and y>225 and y<350) or (x>415) or (x<401 and y>224 and y<350) or y>369 or (x<401 and y<351 and y>224)) and p==6 and l==True:    
    zwes=zwes-1
    if zwes==0:
      screen.fill(white)
      p=0
      lost=pygame.image.load('../images/lost.bmp')
      lost=pygame.transform.scale(lost,(775,600))
      screen.blit(lost,(0,0))
      pygame.display.flip()
      sound=pygame.mixer.Sound('../sounds/defeat.wav')
      sound.play()
    x=285
    y=100
    p=p-1
  #oria kinisis 4ou epipedou
  if (x<280 or x>420 or y<100 or (((mx-t1x)*(mx-t1x)+((my-(t1y+10))*(my-(t1y+10))))<=800 or ((((mx-t2x)*(mx-t2x))+((my-(t2y+10))*(my-(t2y+10))))<=800))) and p==8 and l==True:
    zwes=zwes-1
    if zwes==0:
      screen.fill(white)
      p=0
      lost=pygame.image.load('../images/lost.bmp')
      lost=pygame.transform.scale(lost,(775,600))
      screen.blit(lost,(0,0))
      pygame.display.flip()
      sound=pygame.mixer.Sound('../sounds/defeat.wav')
      sound.play()
    x=347
    y=125
    p=p-1
  #oria kinisis 5ou epipedou 
  if (((((mx-my)<=20 or ((mx-110-my)<=20)and mx>my+90)and my<301 and my>90))or (mx>390 and my>300 and my<480 ) or (mx<312 and my>300)or (my>529)or(my<490 and mx>390)or(mx>480 and my>500)or(((mx-sx)*(mx-sx)+(my-sy)*(my-sy))<=800)) and p==10 and l==True:
    zwes=zwes-1
    if zwes==0:
      screen.fill(white)
      p=0
      lost=pygame.image.load('../images/lost.bmp')
      lost=pygame.transform.scale(lost,(775,600))
      screen.blit(lost,(0,0))
      pygame.display.flip()
      sound=pygame.mixer.Sound('../sounds/defeat.wav')
      sound.play()
    x=160
    y=101
    p=p-1
  #8esi xaraktira 2
  if (p==3 or p==4) and l==True:
    x=347
    y=125
  #8esi xaraktira 3
  if (p==5 or p==6) and l==True:
    x=285
    y=100
  #8esi xaraktira 4
  if (p==7 or p==8) and l==True:
    x=347
    y=125
  #8esi xaraktira 5
  if p==9 or p==10 and l==True:
    x=160
    y=101
  #minimata pou emfanizontai ston paikth sto paixnidi
  if y>500 and p==2:
     screen.fill(white)
     start=pygame.image.load('../images/stage2.bmp')
     start=pygame.transform.scale(start,(775,600))
     screen.blit(start,(0,0))
     pygame.display.flip()   
     l=False
     e=1
  if (mx<340 and my>300) and p==4:
     screen.fill(white)
     start=pygame.image.load('../images/stage3.bmp')
     start=pygame.transform.scale(start,(775,600))
     screen.blit(start,(0,0))
     pygame.display.flip()   
     l=False
     e=1
  if (mx<280 and my>300)and p==6:
     screen.fill(white)
     start=pygame.image.load('../images/stage4.bmp')
     start=pygame.transform.scale(start,(775,600))
     screen.blit(start,(0,0))
     pygame.display.flip()   
     l=False
     e=1
  if my>510 and p==8:
     screen.fill(white)
     start=pygame.image.load('../images/stage5.bmp')
     start=pygame.transform.scale(start,(775,600))
     screen.blit(start,(0,0))
     pygame.display.flip()   
     l=False
     e=1
  if mx>574 and p==10:
     screen.fill(white)
     start=pygame.image.load('../images/won.bmp')
     start=pygame.transform.scale(start,(775,600))
     screen.blit(start,(0,0))
     pygame.display.flip()   
     sound=pygame.mixer.Sound('../sounds/win.wav')
     sound.play()
     l=False
     e=1
pygame.quit()  
  
    
