package ex_2_1_day;

/*
 * Author: Panagiotis Lamprakis
 * 
 */


import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
	
	public class Map extends Mapper<Object, Text, Text, IntWritable>{

		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();

		public void map(Object key, Text value, Context context)
				throws IOException, InterruptedException {


			String line = value.toString();
			String[] input = line.split("\\t");
    
			DateFormat dateYear = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat takeDay = new SimpleDateFormat("dd");
			Date wholeYear;
			String day = " ";
			try {
				wholeYear = dateYear.parse(input[2]);
				day = takeDay.format(wholeYear);
				
				word.set(day);
				context.write(word, one);

			}
			catch (ParseException e1) {
				// TODO Auto-generated catch block
			}
	
		}
	}
